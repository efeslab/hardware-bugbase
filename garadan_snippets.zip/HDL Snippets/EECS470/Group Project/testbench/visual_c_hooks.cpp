/////////////////////////////////////////////
//
// Last update by Liran Xiao, 09/2019
//
/////////////////////////////////////////////
#include "DirectC.h"
#include <curses.h>
#include <stdio.h>
#include <signal.h>
#include <ctype.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <unistd.h> 
#include <fcntl.h> 
#include <time.h>
#include <string.h>
#include <cassert>

#include "riscv_inst.h"

#define DEBUG

// `ifndef N
// 	`define N 4
// `endif
// `define BRANCH_UNITS 4
// `define DC_ASSOC 4
// `define DC_BUF_SZ 8
// `define IC_ASSOC 4
// `define RAT_SIZE 32
// `define ROB_SIZE 32
// `define PRF_SIZE (`RAT_SIZE + `ROB_SIZE)
// `define RS_SIZE 8
// `define NUM_ALUS `N
// `define SQ_SIZE 8
// `define LB_SIZE 8
// // N / 2 round down
// `define NUM_MULTS (`N / 2)
// // N / 2 round up
// `define NUM_LD_CDB ((`N + 1) / 2)

#define PARENT_READ     readpipe[0]
#define CHILD_WRITE     readpipe[1]
#define CHILD_READ      writepipe[0]
#define PARENT_WRITE    writepipe[1]
#define NUM_HISTORY     256
#define NUM_ARF         32
#define NUM_STAGES      8
#define NOOP_INST       0x00000013
#define NUM_REG_GROUPS  4
#define REG_SIZE_IN_HEX 8

#ifndef N
#define N 3
#endif

//+ Add entry numbers
//! They are NOT tied to the values defined in sys_defs.sv, so check there
#define NUM_SQ_ENTRIES 8 	// `SQ_SIZE -- sys_defs.svh 
#define NUM_LB_ENTRIES 32 	// `LB_SIZE*4 b/c 4 bytes loaded per entry
#define NUM_ROB_ENTRIES 32
#define NUM_RS_ENTRIES 8	// `RS_SIZE
#define NUM_RAT_ENTRIES    32
#define NUM_RRAT_ENTRIES    32

//+ Add REG numbers
#define NUM_SQ_REGS    8 
#define NUM_LB_REGS    8
#define NUM_ROB_REGS   6
#define NUM_RS_REGS    8
#define NUM_RAT_REGS   4 
#define NUM_RRAT_REGS  4 


// random variables/stuff
int fd[2], writepipe[2], readpipe[2];
int stdout_save;
int stdout_open;
void signal_handler_IO (int status);
int wait_flag=0;
char done_state;
char echo_data;
FILE *fp;
FILE *fp2;
int setup_registers = 0;
int stop_time;
int done_time = -1;
char time_wrapped = 0;
char readbuffer[1024];

// Structs to hold information about each register/signal group
typedef struct win_info {
	int height;
	int width;
	int starty;
	int startx;
	int color;
} win_info_t;

typedef struct reg_group {
	WINDOW *reg_win;
	char ***reg_contents;
	char **reg_names;
	int num_regs;
	win_info_t reg_win_info;
} reg_group_t;

typedef struct mod_group {
	win_info_t *win_info;
	WINDOW *win;
	char* mod_name;
	char**** contents;
	char** reg_names;
	int* reg_pos;
	int* reg_widths;
	int num_entries;
	int num_regs;
} mod_group_t;


// Window pointers for ncurses windows
//+ add WINDOW def
WINDOW *title_win;
WINDOW *comment_win;
WINDOW *time_win;
WINDOW *sim_time_win;
WINDOW *instr_win;
WINDOW *pipe_win;
WINDOW *clock_win;
WINDOW *arf_win;
WINDOW *rob_win;
WINDOW *rs_win;
WINDOW *sq_win;
WINDOW *lb_win;

WINDOW *rat_win;
WINDOW *rrat_win;
// arrays for register contents and names

int history_num=0;

// declare xx_contents
char **timebuffer;
char **cycles;
char *clocks;
char *resets;
char **inst_contents; // pipe_win
// char **arf_contents;

//@ use regex on draft position x width: (x\d.(\s?)+) -> ,
//+ TODO: define x position of data columns
int rob_reg_pos[NUM_ROB_REGS] = {2, 8, 14, 25, 31, 37};
int rs_reg_pos[NUM_RS_REGS] = {2,7,12,18,28,32,42,45};
int sq_reg_pos[NUM_SQ_REGS] = {2,6,9,15,25,30,40,44}; 
int lb_reg_pos[NUM_LB_REGS] = {2,6,9,15,25,30,40,44};
int rat_reg_pos[NUM_RAT_REGS] = {2, 7, 12, 19};
int rrat_reg_pos[NUM_RAT_REGS] = {2, 7, 12, 19};
//+ TODO: define register data field widths in chars/digits (+1 b/c strings)
//@ use regex on draft position x width: (\s?)+(\d+x)(\d)[dbh] -> ,$3
int rob_reg_widths[NUM_ROB_REGS] = {3, 3, 9, 2, 2, 2};
int rs_reg_widths[NUM_RS_REGS] = {2,2,2,8,1,8,1,1};
int sq_reg_widths[NUM_SQ_REGS] = {2,1,2,8,1,8,1,8}; 
int lb_reg_widths[NUM_LB_REGS] = {2,1,2,8,1,8,1,8};
int rat_reg_widths[NUM_RAT_REGS] = {3,3,2,9};
int rrat_reg_widths[NUM_RAT_REGS] = {3,3,2,9};
//+ TODO: define reg_names
//@ use regex on draft names: ([^\s]+)(\s?)+ -> "$1",
char* rob_reg_names[NUM_ROB_REGS] = {"ARN", "PRN", "NPC", "excp" , "wrmm" , "misp"};
char* rs_reg_names[NUM_RS_REGS] = {  "RS","ROB", "LSQ","Data1","v1","Data2","v2","Ready",};
char* sq_reg_names[NUM_SQ_REGS] = { "SQ#","v","ROB","Addr",".v","Data",".v","ClrDep"}; 
char* lb_reg_names[NUM_LB_REGS] = { "LB#","v","ROB","Addr",".v","Data",".v","Depend"};
// TODO: LSQ bois: add 'is_head' or something
// char* prf_reg_names[NUM_PRF_REGS] = {"RAT", "ARN", "PRN", "Data"};
char* rat_reg_names[NUM_RAT_REGS] = {"RAT", "PRN", "Valid", "Data"};
char* rrat_reg_names[NUM_RRAT_REGS] = {"RRAT", "PRN", "Valid", "Data"};
// TODO: LB: add PRN?

// TODO: figure out reflowing window or scrolling if time allows (lol)
// TODO: try winResize() fcn from ncurses to resize window since my sighandler seems not to work
//+ TODO: add win_info and mod_group
// height, width, starty, startx, color=5;
// RS top left
win_info_t rs_win_info {37,50,3,0,5};
mod_group_t *rs;
// ROB to right of RS
win_info_t rob_win_info {37,43,3,rs_win_info.startx+rs_win_info.width,5};
mod_group_t *rob;
// SQ to right of ROB
win_info_t sq_win_info {13,54,3,rob_win_info.startx+rob_win_info.width,5};
mod_group_t *sq;
// LB below SQ
win_info_t lb_win_info {37,54,sq_win_info.starty+sq_win_info.height,rob_win_info.startx+rob_win_info.width,5};
mod_group_t *lb;
// More will have to go below this full top row
win_info_t rat_win_info {37,28,3,sq_win_info.startx+sq_win_info.width,1};
mod_group_t *rat;

win_info_t rrat_win_info {37,28,3,rat_win_info.startx+rat_win_info.width,8};
mod_group_t *rrat;


//+ Increment NUM_MODULES for each module you add.
#define NUM_MODULES 6
mod_group_t* mod_list[NUM_MODULES];
//+ TODO: add module's indicator char (prefix in simulator $display) to mod_chars
char mod_chars[NUM_MODULES+1] = { 'x', 'r', 'q', 'l', 's', 'a'};
//+ Next, instantiate module using newModule() in initCurses()
//+ Hint: ctrl+F "rob = newModule" and copy its format with the parameters you defined above
//@ Current indicators are: "fipmsrtqhc"
//! DO NOT USE 'c' 't' 'z'
// # Modules
// RS          : s
// ROB         : r  v/
// RAT		   : x
// RRAT  	   : a
// SQ          : q  v/
// LB          : l  
// Cache       : h
// # Stages
// Fetch       : f
// Issue       : i
// Dispatch    : p
// Commit      : m
// # Signals
// CDB         : c



WINDOW *create_newwin(int height, int width, int starty, int startx, int color);
void update_clock(char clock_val);
int get_time();
void setup_gui(FILE *fp);
extern "C" void initcurses();
int processinput();
void parsedata(int history_num_in);
void parse_register(char* readbuf, int reg_num, char*** contents, char** reg_names);
void resizeHandler(int sig);
void* draw_windows(int termcols, int termlines);
void destroy_win(WINDOW *local_win);
void* undraw_windows();
void quit();
mod_group_t* newModule(char *mod_name, int num_entries, int num_regs, 
						int reg_pos[], int reg_widths[], char** reg_names, win_info_t win_info);
mod_group_t* freeModule(mod_group_t *mod);
WINDOW* setup_module(mod_group_t* mod);
void process_module(mod_group_t* mod);

// Helper function for ncurses gui setup
WINDOW *create_newwin(int height, int width, int starty, int startx, int color){
	WINDOW *local_win;
	local_win = newwin(height, width, starty, startx);
	wbkgd(local_win,COLOR_PAIR(color));
	wattron(local_win,COLOR_PAIR(color));
	box(local_win,0,0);
	wrefresh(local_win);
	return local_win;
}

WINDOW *create_newwin_winfo(win_info_t* winfo){
	return create_newwin(winfo->height, winfo->width, winfo->starty, winfo->startx, winfo->color);
}



// Function to draw positive edge or negative edge in clock window
void update_clock(char clock_val){
	static char cur_clock_val = 0;
	// Adding extra check on cycles because:
	//  - if the user, right at the beginning of the simulation, jumps to a new
	//    time right after a negative clock edge, the clock won't be drawn
	// int cycle_len = strlen(cycles[history_num]);
	// fprintf(stderr, "strlen(cycles[history_num]): %d", cycle_len);
	// fprintf(stderr, "cycles[history_num]: %s", cycles[history_num]);
	if((clock_val != cur_clock_val) || strncmp(cycles[history_num],"      0",7) == 1){
	// if (clock_val != cur_clock_val) {
		mvwaddch(clock_win,3,7,ACS_VLINE | A_BOLD);
		if(clock_val == 1){

			//we have a posedge
			mvwaddch(clock_win,2,1,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,ACS_ULCORNER | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			mvwaddch(clock_win,4,1,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_LRCORNER | A_BOLD);
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
		} else {

			//we have a negedge
			mvwaddch(clock_win,4,1,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,ACS_LLCORNER | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			mvwaddch(clock_win,2,1,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_HLINE | A_BOLD);
			waddch(clock_win,ACS_URCORNER | A_BOLD);
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
			waddch(clock_win,' ');
		}
	}
	cur_clock_val = clock_val;
	wrefresh(clock_win);
}


// Function to create and initialize the gui
// Color pairs are (foreground color, background color)
// If you don't like the dark backgrounds, a safe bet is to have
//   COLOR_BLUE/BLACK foreground and COLOR_WHITE background
void setup_gui(FILE *fp){
	initscr();
	if(has_colors()){
		start_color();
		init_pair(1,COLOR_CYAN,COLOR_BLACK);    // shell background
		init_pair(2,COLOR_YELLOW,COLOR_RED);
		init_pair(3,COLOR_RED,COLOR_BLACK);
		init_pair(4,COLOR_YELLOW,COLOR_BLUE);   // title window
		init_pair(5,COLOR_YELLOW,COLOR_BLACK);  // register/signal windows
		init_pair(6,COLOR_RED,COLOR_BLACK);
		init_pair(7,COLOR_MAGENTA,COLOR_BLACK); // pipeline window
		init_pair(8,COLOR_BLUE, COLOR_BLACK);
	}
	curs_set(0);

	// standard ncurses init fxns
	noecho();
	cbreak();
	keypad(stdscr,TRUE);
	wbkgd(stdscr,COLOR_PAIR(1));
	wrefresh(stdscr);
	int pipe_width=0;

	// Moved into function so it can be called again to resize windows
	draw_windows(COLS, LINES);

	refresh();
}


//! Child-main
//this initializes a ncurses window and sets up the arrays for exchanging reg information
extern "C" void initcurses(){
	int nbytes;
	int ready_val;
	done_state = 0;
	echo_data = 1;

	// multiprocessing setup
	// basically, set up 2x one-way pipes for stdin/out <--> child process
	// create a clone of this process (fork)
	// tell the child what to do in the (if childpid==0) block
	// then proceed with parent code
	pid_t childpid;
	pipe(readpipe);
	pipe(writepipe);
	childpid = fork();

	//! Debugger main process
	if(childpid == 0){
		close(PARENT_WRITE);
		close(PARENT_READ);
		// pipe from stdout of parent -- source of simulation output
		fp = fdopen(CHILD_READ, "r");
		// pipe to file for dumping output
		fp2 = fopen("program.out","w");

		// setup handler to reset layout on terminal resize
		signal(SIGWINCH, resizeHandler);

		//+ TODO: instantiate newly defined module using parameters defined above
		rob = newModule("ROB", NUM_ROB_ENTRIES, NUM_ROB_REGS, rob_reg_pos, rob_reg_widths, rob_reg_names, rob_win_info);
		rs = newModule("RS", NUM_RS_ENTRIES, NUM_RS_REGS, rs_reg_pos, rs_reg_widths, rs_reg_names, rs_win_info);
		sq = newModule("SQ", NUM_SQ_ENTRIES, NUM_SQ_REGS, sq_reg_pos, sq_reg_widths, sq_reg_names, sq_win_info); 
		lb = newModule("LB", NUM_LB_ENTRIES, NUM_LB_REGS, lb_reg_pos, lb_reg_widths, lb_reg_names, lb_win_info);
		
		rat = newModule("RAT", NUM_RAT_ENTRIES, NUM_RAT_REGS, rat_reg_pos, rat_reg_widths, rat_reg_names, rat_win_info);
		rrat = newModule("RRAT", NUM_RRAT_ENTRIES, NUM_RRAT_REGS, rrat_reg_pos, rrat_reg_widths, rrat_reg_names, rrat_win_info);
		//+ TODO: add module to mod_list
		mod_list[0] = rat;
		mod_list[1] = rob;
		mod_list[2] = sq;
		mod_list[3] = lb;
		mod_list[4] = rs;
		mod_list[5] = rrat;

		//allocate room on the heap for the reg data
		// * 	= history * char
		// ** 	= history * string
		// *** 	= history * list of strings = 'register'
		// **** = history * array of list of strings = 'module' or ROB-style
		timebuffer        = (char**) malloc(NUM_HISTORY*sizeof(char*));
		cycles            = (char**) malloc(NUM_HISTORY*sizeof(char*));
		inst_contents     = (char**) malloc(NUM_HISTORY*sizeof(char*));
		clocks            = (char*) malloc(NUM_HISTORY*sizeof(char));
		resets            = (char*) malloc(NUM_HISTORY*sizeof(char));

		// int j=0;
		for(int i=0;i<NUM_HISTORY;i++){
			timebuffer[i]       = (char*) malloc(8);
			cycles[i]           = (char*) malloc(7);
			inst_contents[i]    = (char*) malloc(NUM_STAGES*10);
		}

		setup_gui(fp);

		//! Main loop for retrieving data and taking commands from user
		char quit_flag = 0;
		char resp=0;
		char running=0;
		int mem_addr=0;
		char goto_flag = 0;
		char cycle_flag = 0;
		char done_received = 0;
		memset(readbuffer,'\0',sizeof(readbuffer));
		while(!quit_flag){
			// testbench input loop
			if (!done_received) {
				if (sizeof(readbuffer) != 0) {
					fgets(readbuffer, sizeof(readbuffer), fp);
					fputs(readbuffer, stderr);  //! debug
					ready_val = processinput();
				}
			}
			// testbench completion check
			if(strcmp(readbuffer,"DONE") == 0) {
				done_received = 1;
				done_time = history_num - 1;
			}
			// post-testbench cleanup?
			if(ready_val == 1 || done_received == 1){
				if(echo_data == 0 && done_received == 1) {
					running = 0;
					timeout(-1);
					echo_data = 1;
					history_num--;
					history_num%=NUM_HISTORY;
				}
				if(echo_data != 0){
					parsedata(history_num);
				}
				history_num++;
				// keep track of whether time wrapped around yet
				if (history_num == NUM_HISTORY)
					time_wrapped = 1;
				history_num%=NUM_HISTORY;

				//we're done reading the reg values for this iteration
				if (done_received != 1) {
					#ifdef DEBUG
					fputs("done_received != 1", stderr);
					#endif
					write(CHILD_WRITE, "n", 1);
					write(CHILD_WRITE, &mem_addr, 2);
				}
				//* Why tf are these here?
				char continue_flag = 0;
				int hist_num_temp = (history_num-1)%NUM_HISTORY;
				if (history_num==0) hist_num_temp = NUM_HISTORY-1;
				char echo_data_tmp,continue_flag_tmp;

				while(continue_flag == 0){
					//! get user input - ncurses
					resp=getch();
					if(running == 1){
						continue_flag = 1;
					}
					if(running == 0 || resp == 'p'){ 
						//+ OPT: Add gui command chars
						// TODO: make a 'run slowly' option, maybe a number after r is pressed?
						if(resp == 'n' && hist_num_temp == (history_num-1)%NUM_HISTORY){
							// next cycle
							if (!done_received)
								continue_flag = 1;
						}else if(resp == 'n'){
							// forward in time, but not up to present yet
							hist_num_temp++;
							hist_num_temp%=NUM_HISTORY;
							parsedata(hist_num_temp);
						}else if(resp == 'r'){
							// run to end
							echo_data = 0;
							running = 1;
							timeout(0);	// TODO: adjust?
							continue_flag = 1;
						}else if(resp == 'p'){
							// prev cycle
							echo_data = 1;
							timeout(-1);
							running = 0;
							parsedata(hist_num_temp);
						}else if(resp == 'q'){
							//quit
							continue_flag = 1;
							quit_flag = 1;
						}else if(resp == 'b'){
							// We're goin BACK IN TIME, woohoo!
							// Make sure not to wrap around to NUM_HISTORY-1 if we don't have valid
							// data there (time_wrapped set to 1 when we wrap around to history 0)
							if (hist_num_temp > 0) {
								hist_num_temp--;
								parsedata(hist_num_temp);
							} else if (time_wrapped == 1) {
								hist_num_temp = NUM_HISTORY-1;
								parsedata(hist_num_temp);
							}
						}else if(resp == 'g' || resp == 'c'){
							// goto [cycle | time]

							// See if user wants to jump to clock cycle instead of sim time
							cycle_flag = (resp == 'c');

							// go to specified simulation time (either in history or
							// forward in simulation time).
							stop_time = get_time();
							
							// see if we already have that time in history
							int tmp_time;
							int cur_time;
							int delta;
							int i = 0;
							if (cycle_flag)
								sscanf(cycles[hist_num_temp], "%u", &cur_time);
							else
								sscanf(timebuffer[hist_num_temp], "%u", &cur_time);
							delta = (stop_time > cur_time) ? 1 : -1;
							if ((hist_num_temp+delta)%NUM_HISTORY != history_num) {
								tmp_time=hist_num_temp;
								i = (hist_num_temp+delta >= 0) ? (hist_num_temp+delta)%NUM_HISTORY : NUM_HISTORY-1;
								while (i!=history_num) {
									if (cycle_flag)
										sscanf(cycles[i], "%u", &cur_time);
									else
										sscanf(timebuffer[i], "%u", &cur_time);
									if ((delta == 1 && cur_time >= stop_time) ||
											(delta == -1 && cur_time <= stop_time)) {
										hist_num_temp = i;
										parsedata(hist_num_temp);
										stop_time = 0;
										break;
									}

									if ((i+delta) >=0)
										i = (i+delta)%NUM_HISTORY;
									else {
										if (time_wrapped == 1)
											i = NUM_HISTORY - 1;
										else {
											parsedata(hist_num_temp);
											stop_time = 0;
											break;
										}
									}
								}
							}

							// If we looked backwards in history and didn't find stop_time
							// then give up
							if (i==history_num && (delta == -1 || done_received == 1))
								stop_time = 0;

							// Set flags so that we run forward in the simulation until
							// it either ends, or we hit the desired time
							if (stop_time > 0) {
								// grab current values
								echo_data = 0;
								running = 1;
								timeout(0);
								continue_flag = 1;
								goto_flag = 1;
							}
						}
					}
				}

				// if we're instructed to goto specific time, see if we're there
				int cur_time=0;
				if (goto_flag==1) {
					if (cycle_flag)
						sscanf(cycles[hist_num_temp], "%u", &cur_time);
					else
						sscanf(timebuffer[hist_num_temp], "%u", &cur_time);
					if ((cur_time >= stop_time) ||
							(strcmp(readbuffer,"DONE")==0) ) {
						goto_flag = 0;
						echo_data = 1;
						running = 0;
						timeout(-1);
						continue_flag = 0;
						//parsedata(hist_num_temp);
					}
				}
			}
		}

		// Cleanup tasks
		refresh();
		delwin(title_win);
		endwin();
		// TODO: Clean up the insane memory leaked here
		//! Add quit() here and move these there>
		fflush(stdout);
		if(resp == 'q'){
			// quit
			fclose(fp2);
			write(CHILD_WRITE, "Z", 1);
			quit();
			exit(0);
		}
		readbuffer[0] = 0;
		while(strncmp(readbuffer,"DONE",4) != 0){
			if(fgets(readbuffer, sizeof(readbuffer), fp) != NULL)
				fputs(readbuffer, fp2);
		}
		fclose(fp2);
		fflush(stdout);
		write(CHILD_WRITE, "Z", 1);
		printf("Child Done Execution\n");
		exit(0);
	} else { // parent process cleanup
		// parent doesn't touch these so close them here
		close(CHILD_READ);
		close(CHILD_WRITE);
		// parent's stdout is now PARENT_WRITE, returned to VCS sim
		dup2(PARENT_WRITE, 1); 
		// close the local descriptor of stream to child process
		close(PARENT_WRITE);
	}
}


// This function updates all of the signals being displayed with the values
// from time history_num_in (this is the index into all of the data arrays).
// If the value changed from what was previously display, the signal has its
// display color inverted to make it pop out.
// R:	All data for each window has been written to xx_contents
//! update windows with pre-processed date
void parsedata(int history_num_in){
	int termcols = getmaxx(stdscr);
	static int old_history_num_in=0;
	static int old_head_position=0;
	static int old_tail_position=0;
	int i=0;
	int data_counter=0;
	int tmp=0;
	int tmp_val=0;
	char tmp_buf[32];
	mod_group_t* curmod;

	// Handle updating resets
	if (resets[history_num_in]) {
		wattron(title_win,A_REVERSE);
		mvwprintw(title_win,1,(termcols/2)-3,"RESET");
		wattroff(title_win,A_REVERSE);
	}
	else if (done_time != 0 && (history_num_in == done_time)) {
		wattron(title_win,A_REVERSE);
		mvwprintw(title_win,1,(termcols/2)-3,"DONE ");
		wattroff(title_win,A_REVERSE);
	}
	else
		mvwprintw(title_win,1,(termcols/2)-3,"     ");
	wrefresh(title_win);

	//+ Handle updating data displayed in window - genericized
	for (int m=0; m<NUM_MODULES; ++m) {
		curmod = mod_list[m];
		for (int entry=0; entry < curmod->num_entries; ++entry) {
			// update values on screen
			for (int reg=0; reg < curmod->num_regs; ++reg) {
				// invert background color if value changed
				if (strcmp(curmod->contents[history_num_in][entry][reg],
										curmod->contents[old_history_num_in][entry][reg]))
					wattron(curmod->win, A_REVERSE);
				else
					wattroff(curmod->win, A_REVERSE);
				mvwaddstr(curmod->win, (entry+4), curmod->reg_pos[reg], 
							curmod->contents[history_num_in][entry][reg]);
			}
		}
		wrefresh(curmod->win);
	}

	//update the time window
	mvwaddstr(time_win,1,1,timebuffer[history_num_in]);
	wrefresh(time_win);

	//update to the correct clock edge for this history
	mvwaddstr(clock_win,1,7,cycles[history_num_in]);
	update_clock(clocks[history_num_in]);

	//save the old history index to check for changes later
	old_history_num_in = history_num_in;
}


// Parse a line of data output from the testbench
int processinput(){
	static int byte_num = 0;
	int tmp_len;
	char name_buf[32];
	char val_buf[32];

	char indicator;
	char *indloc;
	int mod_idx;

	#ifdef DEBUG
	fprintf(stderr, "[C] processinput(): readbuffer = %s\n", readbuffer);
	fprintf(stderr, "[C] processinput(): readbuffer[0] = %c\n", readbuffer[0]);
	#endif

	//get rid of newline character
	readbuffer[strlen(readbuffer)-1] = 0;

	// All regs for entry received, return(1) to update windows
	// only short-circuit case
	if (strncmp(readbuffer,"break",3) == 0) {
		mvwaddstr(sim_time_win,1,1,timebuffer[history_num]);
		wrefresh(sim_time_win);
		//tell the parent application we're ready to move on
		return(1); 
	}

	//! non-module types, leaving as-is
	if(strncmp(readbuffer,"t",1) == 0){
		//We are getting the timestamp
		strcpy(timebuffer[history_num],readbuffer+1);
	}else if(strncmp(readbuffer,"c",1) == 0){

		//We have a clock edge/cycle count signal
		if(strncmp(readbuffer+1,"0",1) == 0)
			clocks[history_num] = 0;
		else
			clocks[history_num] = 1;

		// grab clock count (for some reason, first clock count sent is
		// too many digits, so check for this)
		strncpy(cycles[history_num],readbuffer+2,7);
		if (strncmp(cycles[history_num],"       ",7) == 0)
			cycles[history_num][6] = '0';
		
	}else if(strncmp(readbuffer,"z",1) == 0){
		
		// we have a reset signal
		if(strncmp(readbuffer+1,"0",1) == 0)
			resets[history_num] = 0;
		else
			resets[history_num] = 1;

	}else if(strncmp(readbuffer,"p",1) == 0){
		// We are getting information about which instructions are in each stage
		strcpy(inst_contents[history_num], readbuffer+1);
	}else{
		//+ all modules handled here
		// verify that indicator char matches a module-spec
		indicator = readbuffer[0];
		indloc = strchr(mod_chars, indicator);
		if (indloc != NULL) {
			//! not super error-tolerant -- segfaults here usually mean weird sim output
			mod_idx = (int) (indloc - mod_chars);
			// get index of mod* in mod_list from indicator char
			// get mod* from mod_list and pull data in from readbuffer
			process_module(mod_list[mod_idx]);
		} 
	} 

	return(0);
}


//! Parent Function
// Function to make testbench block until debugger is ready to proceed
extern "C" int waitforresponse(){
	static int mem_start = 0;
	char c=0;
	while(c!='n' && c!='Z') read(PARENT_READ,&c,1);
	if(c=='Z') exit(0);
	mem_start = read(PARENT_READ,&c,1);
	mem_start = mem_start << 8 + read(PARENT_READ,&c,1);
	return(0);
}


//! Parent Function
extern "C" void flushpipe(){
	char c=0;
	read(PARENT_READ, &c, 1);
}

// Function to return string representation of opcode given inst encoding
char *get_opcode_str(int inst, int valid_inst)
{
	int opcode, check;
	char *str;

	if (valid_inst == ((int)'x' - (int)'0'))
		str = "-";
	else if (!valid_inst)
		str = "-";
	else if (inst == NOOP_INST)
		str = "nop";
	else
	{
		inst_t dummy_inst;
		dummy_inst.decode(inst);
		str = const_cast<char *>(dummy_inst.str); // due to legacy code..
	}

	return str;
}

// Function to parse register $display() from testbench and add to
// names/contents arrays
//! Initial-read register setup
void parse_register(char *readbuf, int reg_num, char*** contents, char** reg_names) {
	char name_buf[32];
	char val_buf[32];
	int tmp_len;

	sscanf(readbuf,"%*c%s %d:%s",name_buf,&tmp_len,val_buf);
	int i=0;
	for (;i<NUM_HISTORY;i++){
		contents[i][reg_num] = (char*) malloc((tmp_len+1)*sizeof(char));
	}
	strcpy(contents[history_num][reg_num],val_buf);
	reg_names[reg_num] = (char*) malloc((strlen(name_buf)+1)*sizeof(char));
	strncpy(reg_names[reg_num], readbuf+1, strlen(name_buf));
	reg_names[reg_num][strlen(name_buf)] = '\0';
}


// Ask user for simulation time to stop at
// Since the enter key isn't detected, user must press 'g' key
//  when finished entering a number.
int get_time() {
	int termcols = getmaxx(stdscr);
	int col = termcols/2-6;
	wattron(title_win,A_REVERSE);
	mvwprintw(title_win,1,col,"goto time: ");
	wrefresh(title_win);
	int resp=0;
	int ptr = 0;
	char buf[32];
	
	resp=wgetch(title_win);
	while(resp != 'g' && resp != KEY_ENTER && resp != ERR && ptr < 6) {
		if (isdigit((char)resp)) {
			waddch(title_win,(char)resp);
			wrefresh(title_win);
			buf[ptr++] = (char)resp;
		}
		resp=wgetch(title_win);
	}

	// Clean up title window
	wattroff(title_win,A_REVERSE);
	mvwprintw(title_win,1,col,"           ");
	for(int i=0;i<ptr;i++)
		waddch(title_win,' ');

	wrefresh(title_win);

	buf[ptr] = '\0';
	return atoi(buf);
}


void resizeHandler(int sig)
{
	// http://www.cs.ukzn.ac.za/~hughm/os/notes/ncurses.html#window
	int nh, nw;
	// get new screen size
	getmaxyx(stdscr, nh, nw);  /* get the new screen size */
	undraw_windows();
	draw_windows(nh, nw);
}


void destroy_win(WINDOW *local_win)
{	
	/* box(local_win, ' ', ' '); : This won't produce the desired
	 * result of erasing the window. It will leave it's four corners 
	 * and so an ugly remnant of window. 
	 */
	wborder(local_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
	/* The parameters taken are 
	 * 1. win: the window on which to operate
	 * 2. ls: character to be used for the left side of the window 
	 * 3. rs: character to be used for the right side of the window 
	 * 4. ts: character to be used for the top side of the window 
	 * 5. bs: character to be used for the bottom side of the window 
	 * 6. tl: character to be used for the top left corner of the window 
	 * 7. tr: character to be used for the top right corner of the window 
	 * 8. bl: character to be used for the bottom left corner of the window 
	 * 9. br: character to be used for the bottom right corner of the window
	 */
	wrefresh(local_win);
	delwin(local_win);
}


// burn them all
void* undraw_windows() {
	destroy_win(title_win);
	destroy_win(comment_win);
	destroy_win(time_win);
	destroy_win(sim_time_win);
	destroy_win(clock_win);
	destroy_win(rob_win);
}


// Draw them all
void* draw_windows(int termcols, int termlines) {
	// int i=0;
	// int data_counter=0;
	// int tmp=0;
	// int tmp_val=0;
	int pipe_width = termcols/NUM_STAGES;
	char tmp_buf[32];


	//instantiate the title window at top of screen
	title_win = create_newwin(3,termcols,0,0,4);
	mvwprintw(title_win,1,1,"SIMULATION INTERFACE V2");
	mvwprintw(title_win,1,termcols-22,"DATBOI");
	wrefresh(title_win);

	//instantiate time window at right hand side of screen
	time_win = create_newwin(3,10,8,termcols-10,5);
	mvwprintw(time_win,0,3,"TIME");
	wrefresh(time_win);

	//instantiate a sim time window which states the actual simlator time
	sim_time_win = create_newwin(3,10,11,termcols-10,5);
	mvwprintw(sim_time_win,0,1,"SIM TIME");
	wrefresh(sim_time_win);

	//instantiate a window to show which clock edge this is
	clock_win = create_newwin(6,15,8,termcols-25,5);
	mvwprintw(clock_win,0,5,"CLOCK");
	mvwprintw(clock_win,1,1,"cycle:");
	update_clock(0);
	wrefresh(clock_win);

	//instantiate window to visualize instructions in pipeline below title
	// pipe_win = create_newwin(35, termcols, 3, 0, 7);
	// pipe_width = termcols / 6;
	// mvwprintw(pipe_win, 0, (termcols - 8) / 2, "PIPELINE");
	// wattron(pipe_win, A_UNDERLINE);
	// mvwprintw(pipe_win, 1, 1 * pipe_width - 5, "FETCH");
	// mvwprintw(pipe_win, 1, 2 * pipe_width - 6, "DECODE");
	// mvwprintw(pipe_win, 1, 3 * pipe_width - 8, "DISPATCH");
	// mvwprintw(pipe_win, 1, 4 * pipe_width - 8, "ISS-WKUP");
	// mvwprintw(pipe_win, 1, 5 * pipe_width - 7, "ISS-SEL");
	// mvwprintw(pipe_win, 1, 6 * pipe_width - 7, "EXECDLY");
	// mvwprintw(pipe_win, 1, 7 * pipe_width - 8, "EXECMPLT");
	// mvwprintw(pipe_win, 1, 8 * pipe_width - 6, "COMMIT");
	// wattroff(pipe_win, A_UNDERLINE);
	// wrefresh(pipe_win);

	// instantiate a window for each module in the defined positions
	for (int m=0; m<NUM_MODULES; ++m) {
		mod_list[m]->win = setup_module(mod_list[m]);
	}

	//instantiate an instructional window to help out the user some
	instr_win = create_newwin(7,30,termlines-7,0,5);
	mvwprintw(instr_win,0,9,"INSTRUCTIONS");
	wattron(instr_win,COLOR_PAIR(5));
	mvwaddstr(instr_win,1,1,"'n'   -> Next clock edge");
	mvwaddstr(instr_win,2,1,"'b'   -> Previous clock edge");
	mvwaddstr(instr_win,3,1,"'c/g' -> Goto specified time");
	mvwaddstr(instr_win,4,1,"'r'   -> Run to end of sim");
	mvwaddstr(instr_win,5,1,"'q'   -> Quit Simulator");
	wrefresh(instr_win);
	
	refresh();
}


//! Memory and terminal cleanup
void quit() {
	refresh();
	// delwin(rob->win); // todo: genericize

	for (int i=0; i<NUM_MODULES; ++i) {
		mod_list[i] = freeModule(mod_list[i]);
	}
	endwin();
}



//	R:	pointer to mod_group_t
//	M:	mallocs mod_group and all internal pointer data, free it!
//	E:	
mod_group_t* newModule(char *mod_name, int num_entries, int num_regs, int reg_pos[], int reg_widths[], char** reg_names, win_info_t win_info) {
	//+ allocate structs
	mod_group_t *mod = (mod_group_t*) malloc(sizeof(mod_group_t));
	#ifdef DEBUG
	assert(mod != NULL);
	#endif

	//+ allocate struct contents - seems like I could make a constructor(mod*, num_entries, num_regs)
	mod->win			= NULL;			
	mod->mod_name		= (char*) 		malloc(strlen(mod_name));
	mod->contents		= (char****) 	malloc(NUM_HISTORY*sizeof(char***));
	mod->reg_names		= (char**) 		malloc(num_regs*sizeof(char*));
	mod->reg_pos		= (int*)		malloc(num_regs*sizeof(int));
	mod->reg_widths		= (int*)		malloc(num_regs*sizeof(int));
	mod->num_entries	= num_entries;
	mod->num_regs		= num_regs;
	mod->win_info		= (win_info_t*)	malloc(sizeof(win_info_t));

	#ifdef DEBUG
	assert(mod->contents != NULL);
	assert(mod->reg_names != NULL);
	assert(mod->reg_pos != NULL);
	assert(mod->reg_widths != NULL);
	assert(mod->win_info != NULL);
	#endif

	//+ assign reg_widths, reg_pos, and mod_name
	memcpy(mod->reg_widths, reg_widths, (sizeof(int)*num_regs));
	memcpy(mod->reg_pos, reg_pos, (sizeof(int)*num_regs));
	strcpy(mod->mod_name, mod_name);

	//+ assign reg_names
	for (int r=0; r<num_regs; ++r) {
		mod->reg_names[r] = (char*) malloc(strlen(reg_names[r])*sizeof(char));
		strcpy(mod->reg_names[r], reg_names[r]);
	}

	//+ allocate xx_contents: history, entries, regs
	for(int h=0;h<NUM_HISTORY;h++){
		mod->contents[h] = (char***) malloc(num_entries*sizeof(char**));
		for (int e=0;e<num_entries;++e) {
			mod->contents[h][e] = (char**) malloc(num_regs*sizeof(char*));
			//+ if at all possible, make this happen here
			for (int r=0;r<num_regs;++r) {
				mod->contents[h][e][r] = (char*) malloc((mod->reg_widths[r]+1)*sizeof(char));
				// contents[i][j][reg_num] = (char*) malloc((tmp_len+1)*sizeof(char));
			}
		}
	}

	//+ assign win_info
	*(mod->win_info) = win_info;

	return mod;
}

// TODO: check delwin and endwin behavior w.r.t memory
// R:	Should probably run after running endwin(mod)
// M: 	Frees all the data associated with a module mod_group_t
mod_group_t* freeModule(mod_group_t *mod) {

	//+ free mod_contents: history, entries, regs
	for(int h=0;h<NUM_HISTORY;h++){
		for (int e=0;e<mod->num_entries;++e) {
			for (int r=0;r<mod->num_regs;++r) {
				free(mod->contents[h][e][r]);
			}
			free(mod->contents[h][e]);
		}
		free(mod->contents[h]);
	}
	//+ free reg_names
	for (int r=0;r<mod->num_regs;++r) {
		free(mod->reg_names[r]);
	}
	//+ free struct contents - seems like I could make a constructor(mod*, num_entries, num_regs)
	delwin(mod->win);
	// free(mod->win);			// careful with this one, not sure what ncurses expects
	free(mod->mod_name);
	free(mod->contents);
	free(mod->reg_names);
	free(mod->reg_pos);
	free(mod->reg_widths);
	free(mod->win_info);
	free(mod);	// might also need to wait on this one until after ncurses done

	mod = NULL;
	return mod;
}



//@ genericizing process_input for modules
// write new module reg-data into contents
void process_module(mod_group_t* mod) {
	static int reg_num = 0;
	static int entry_num = 0;

	int entry_num_read = 0;
	int tmp_len;
	char name_buf[32];
	char val_buf[32];

	#ifdef DEBUG
	// fputs("[C] process_module(): readbuffer = ", stderr);
	// fputs(readbuffer, stderr);
	fprintf(stderr, "[C] process_module(): readbuffer = {%s}\n", readbuffer);
	fprintf(stderr, "[C] process_module(): readbuffer[0] = {%c}\n", readbuffer[0]);
	#endif
	
	sscanf(readbuffer,"%*c%s %d %d:%s", name_buf, &entry_num_read, &tmp_len, val_buf);

	#ifdef DEBUG
	fprintf(stderr, "entry_num_read: %d\nentry_num: %d\n", entry_num_read, entry_num);
	fprintf(stderr, "val_buf: %s\ntmp_len: %d\nname_buf: %s\n", val_buf, tmp_len, name_buf);
	assert((entry_num_read == entry_num) || entry_num_read == 'x');
	#endif

	strcpy(mod->contents[history_num][entry_num][reg_num],val_buf);

	// if all regs in entry updated:
	if (reg_num < mod->num_regs-1) {
		reg_num++;
	} else {
		// triggers AFTER last mod->reg_num++, bc last-idx is num-1
		entry_num++;
		reg_num = 0;
		// l337 haxor would write:
		// entry_num = ++entry_num % mod->entry_num-1;
		if (entry_num == mod->num_entries) {
			entry_num = 0;
		}
	}
}

//@ Separating window definition for modules
// Create and display window for module on startup/resize
// R: mod->win_info, ->num_regs, ->reg_pos, ->reg_names, ->mod_name
WINDOW* setup_module(mod_group_t* mod) {
	//+ Add window definition for GUI
	// instantiate a window for the ROB on the right side
	// tmp_win = create_newwin(48,43,4,0,5);
	WINDOW* tmp_win = create_newwin_winfo(mod->win_info);
	int win_hcenter = mod->win_info->width/2;
	int title_pos = win_hcenter - (strlen(mod->mod_name)/2);
	// TODO: Try 0 in 2nd arg for title-in-border
	mvwprintw(tmp_win, 1, title_pos, mod->mod_name);
	// horizontal line between window title and col headers
	mvwhline(tmp_win, 2, 1, 0, mod->win_info->width - 2);
	// Write column headers in row 3
	for (int r=0; r<mod->num_regs; ++r) {
		mvwprintw(tmp_win, 3, mod->reg_pos[r], mod->reg_names[r]);
	}
	wrefresh(tmp_win);
	return tmp_win;
}


