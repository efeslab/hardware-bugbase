I don't currently have access to the ARI Computer, so I'll update this shortly with code from my current project!

Code in this folder will all be VHDL, unfortunately. These will be shorter modules with plenty of stylistic and logical errors.